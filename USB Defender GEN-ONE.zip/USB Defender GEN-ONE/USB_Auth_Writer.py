# General idea make a helper that automatically creates the auth file for a USB
# program starts and records what drives are already connected
# then it keeps checking for a newly connected drive
# when a new drive is plugged in identify which drive is new
# pull available metadata from the new drive
# use the drive serial number as the main value for the auth file
# encode the serial using a three digit Org ID
# add a small ID marker to the encoded data
# write the encoded data into USB_ID.txt directly on the USB
# this file is used to create the TXT file that authenicates the USB
# no button and no manually selecting the drive
# start the program then plug in the USB and it should write the file automatically
# after writing the file wait until the USB is removed
# once it is removed go back to waiting for the next USB
# Org ID should be saved locally so it only needs to be entered during setup
# final flow start program ->
# plug in USB ->
# detect drive ->
# pull serial ->
# encode serial ->
# write auth file ->
# wait for removal ->
# ready again

letter_values_L = {
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5,
    "f": 6,
    "g": 7,
    "h": 8,
    "i": 9,
    "j": 10,
    "k": 11,
    "l": 12,
    "m": 13,
    "n": 14,
    "o": 15,
    "p": 16,
    "q": 17,
    "r": 18,
    "s": 19,
    "t": 20,
    "u": 21,
    "v": 22,
    "w": 23,
    "x": 24,
    "y": 25,
    "z": 26
}

letter_values_U = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
    "F": 6,
    "G": 7,
    "H": 8,
    "I": 9,
    "J": 10,
    "K": 11,
    "L": 12,
    "M": 13,
    "N": 14,
    "O": 15,
    "P": 16,
    "Q": 17,
    "R": 18,
    "S": 19,
    "T": 20,
    "U": 21,
    "V": 22,
    "W": 23,
    "X": 24,
    "Y": 25,
    "Z": 26
}

import ctypes
import string
import time
from pathlib import Path

try:
    File = open("Org_ID.txt", "r")
    Org_ID = File.read()
    File.close()

    while not len(Org_ID) == 3 or not Org_ID.isdigit():
        Org_ID = input(
            'Invalid Organization ID.\n'
            'Please enter exactly three numbers, example: 123\n'
            '> '
        )

    File = open("Org_ID.txt", "w")
    File.write(Org_ID)
    File.close()

except FileNotFoundError:
    print(
        'No Organization ID configuration was found.\n'
        'A three-digit Organization ID is required before USB devices can be registered.'
    )

    Org_ID = input(
        'Enter your three-digit Organization ID, example: 123\n'
        '> '
    )

    while not len(Org_ID) == 3 or not Org_ID.isdigit():
        Org_ID = input(
            'Invalid Organization ID.\n'
            'Please enter exactly three numbers.\n'
            '> '
        )

    File = open("Org_ID.txt", "w")
    File.write(Org_ID)
    File.close()

import win32api
import win32file

Drives = win32api.GetLogicalDriveStrings()
Drives = Drives.split('\000')[:-1]
NATIVE = Drives.copy()

print(
    'USB Registration Utility Started.\n'
    'Waiting for a USB storage device to be connected...'
)

while 1 == 1:
    New_Drives = win32api.GetLogicalDriveStrings()
    New_Drives = New_Drives.split('\000')[:-1]

    if (New_Drives == NATIVE) is False:
        PASS = New_Drives.copy()
        TEMP = New_Drives.copy()

        for X in PASS:
            if X in NATIVE:
                TEMP.remove(X)

        if len(TEMP) > 0:
            print(
                f'\nNew USB device detected: {TEMP[0]}\n'
                'Reading device information...'
            )

            Volume_Info = win32api.GetVolumeInformation(TEMP[0])
            Serial_Num = str(abs(Volume_Info[1]))

            print(f'Device Serial Number: {Serial_Num}')

            Encoded_Str = ['ID']

            for Pos in range(0, len(Serial_Num)):
                Con = Serial_Num[Pos]

                if Con.isalpha():
                    if Con.islower():
                        Con = int(letter_values_L[Con]) + 9 + 26
                    else:
                        Con = int(letter_values_U[Con]) + 9
                else:
                    Con = int(Con)

                OPos1 = int(Org_ID[0]) + 13
                OPos2 = int(Org_ID[1]) + 13
                OPos3 = int(Org_ID[2]) + 13

                Con = ((Con + OPos3) * OPos2) - OPos1

                Encoded_Str.append(Con)

            File_Path = TEMP[0]

            File_USB = open(File_Path + "USB_ID.txt", "w")
            File_USB.write(str(Encoded_Str))
            File_USB.close()

            print(
                '\nUSB Registration Complete.\n'
                f'Drive {File_Path} has been registered successfully.\n'
                'The authentication file has been written to the device.\n'
                'Please remove the USB device when ready.'
            )

            TEMP = "Null"

        while (NATIVE == New_Drives) == False:
            New_Drives = win32api.GetLogicalDriveStrings()
            New_Drives = New_Drives.split('\000')[:-1]
            time.sleep(1)

        print(
            '\nUSB device removed.\n'
            'Ready to register another device.'
        )

    time.sleep(1)

print('USB Registration Utility Closed.')

# got the helper working and im pretty happy with where its sitting now
# biggest issue was figuring out how Windows gives the connected drive list and then splitting that into something useful
# also had to figure out how to compare the original drives against the new drive list without messing up the list while changing it
# copying lists was a little annoying because assigning one list to another does not actually make a separate copy
# had an issue where i was passing the whole list of new drives into the volume information check instead of the actual drive path
# also had to account for the fact that a drive being removed also counts as the drive list changing
# added a check so it only tries to read drive information when there is actually a new drive left after removing the original drives
# needed a delay in the loop so it was not checking constantly at full speed
# after the file gets written the program waits until the drive is removed so it does not keep rewriting the same file
# the serial number can come back negative so i made it positive before encoding it
# writing to the USB was easier once i realized the detected drive path could just be used directly with the file name
# the encoded data is currently written as a string version of the list which is fine for what this helper needs to do
# the letter conversion is still in there even though the current serial value is numeric because i may want it later
# current version does what i wanted start it plug in a USB and it automatically creates the auth file with no extra button or drive selection
# im happy with this as the write side for now and dont really want to overcomplicate it before moving on
