# General idea make the background side that checks USBs when they are plugged in
# program starts and records everything already connected as native so it does not bother checking those
# keep watching the connected drives for anything new
# when a new USB shows up look for the USB_ID.txt auth file
# if the file is missing then the drive is not registered and should be flagged
# if the file exists pull the serial number from the drive
# use the local Org ID and the drive serial to recreate what the encoded auth file should contain
# compare the recreated value against the value stored on the USB
# if they match then the USB is registered with this Org and it can be trusted
# once a USB passes the check add it to the native list so the program stops checking the same approved drive
# if they do not match then the USB should be treated the same as one without an auth file
# warn the user that the USB is not registered and may be a threat
# keep track of how long the unknown drive stays connected
# wait until the unknown USB is removed
# after removal print the drive information and serial so it can be reported
# then go back to watching for another USB
# final flow start program ->
# save native drives ->
# detect new USB ->
# look for auth file ->
# recreate auth value from serial ->
# compare values ->
# if valid whitelist and update native list ->
# if invalid warn user ->
# wait for removal ->
# report drive ->
# continue watching

import ctypes
import string
import time
import sys
import win32api
import win32file
from pathlib import Path

letter_values_L = {
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5,
    "f": 6,
    "g": 7,
    "h": 8,
    "i": 9,
    "j": 10,
    "k": 11,
    "l": 12,
    "m": 13,
    "n": 14,
    "o": 15,
    "p": 16,
    "q": 17,
    "r": 18,
    "s": 19,
    "t": 20,
    "u": 21,
    "v": 22,
    "w": 23,
    "x": 24,
    "y": 25,
    "z": 26
}

letter_values_U = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
    "F": 6,
    "G": 7,
    "H": 8,
    "I": 9,
    "J": 10,
    "K": 11,
    "L": 12,
    "M": 13,
    "N": 14,
    "O": 15,
    "P": 16,
    "Q": 17,
    "R": 18,
    "S": 19,
    "T": 20,
    "U": 21,
    "V": 22,
    "W": 23,
    "X": 24,
    "Y": 25,
    "Z": 26
}

T = 0

try:
    File = open("Org_ID.txt", "r")
    Org_ID = File.read()
    File.close()

except FileNotFoundError:
    print(
        "USB Defender could not start because no Organization ID was found.\n"
        "Please complete the setup process before running this program."
    )
    sys.exit()

Drives = win32api.GetLogicalDriveStrings()
Drives = Drives.split('\000')[:-1]
NATIVE = Drives.copy()
UD = False
C = len(NATIVE)

while 1 == 1:
    time.sleep(1)
    UD = False

    Drives = win32api.GetLogicalDriveStrings()
    Drives = Drives.split('\000')[:-1]

    if len(Drives) < C:
        C = len(Drives)
        Drives = win32api.GetLogicalDriveStrings()
        Drives = Drives.split('\000')[:-1]
        NATIVE = Drives.copy()

    if len(Drives) == C:
        Drives = win32api.GetLogicalDriveStrings()
        Drives = Drives.split('\000')[:-1]
        NATIVE = Drives.copy()

    try:
        if len(Drives) > C:
            for X in Drives:

                if X in NATIVE:
                    continue

                else:
                    try:
                        time.sleep(2)

                        File_USB = open(X + "USB_ID.txt", "r")
                        Given_Str = File_USB.read()
                        File_USB.close()

                        Encoded_Str = ['ID']

                        Volume_Info = win32api.GetVolumeInformation(X)
                        Serial_Num = str(abs(Volume_Info[1]))

                        for Pos in range(0, len(Serial_Num)):
                            Con = Serial_Num[Pos]

                            if Con.isalpha():
                                if Con.islower():
                                    Con = int(letter_values_L[Con]) + 9 + 26
                                else:
                                    Con = int(letter_values_U[Con]) + 9
                            else:
                                Con = int(Con)

                            OPos1 = int(Org_ID[0]) + 13
                            OPos2 = int(Org_ID[1]) + 13
                            OPos3 = int(Org_ID[2]) + 13

                            Con = ((Con + OPos3) * OPos2) - OPos1

                            Encoded_Str.append(Con)

                        print(f'Generated Authentication Value: {Encoded_Str}')
                        print(f'Device Authentication Value:    {Given_Str}')

                        if not (f'{Given_Str}') == (f'{Encoded_Str}'):
                            UD = True
                        else:
                            print(f'Device {X} successfully authenticated.')
                            C += 1

                    except FileNotFoundError:
                        print(f'Authentication file not found on device {X}')
                        UD = True

                        Volume_Info = win32api.GetVolumeInformation(X)
                        Serial_Num = str(abs(Volume_Info[1]))

                if UD is True:
                    print(
                        "\nWARNING: Unregistered USB Device Detected\n"
                        "This device is not registered with your organization and may present a security risk.\n"
                        "Please remove the device."
                    )

                    while not Drives == NATIVE:
                        Drives = win32api.GetLogicalDriveStrings()
                        Drives = Drives.split('\000')[:-1]

                        time.sleep(1)

                        T += 1
                        print(f'Device connected for {T} second(s).')

                    print(
                        "\nDevice Removed.\n"
                        f"Please report the following device information:\n"
                        f"Drive: {X}\n"
                        f"Serial Number: {Serial_Num}"
                    )

                    T = 0

    except Exception as Error:
        print(f'USB Defender encountered an error: {Error}')
        continue


# IT WORKS !!!!!!
# got the background checker working with the logic i wanted so far
# biggest issue was keeping track of what drives should count as native and what should actually be checked
# had a problem where the unregistered flag could stay true between loops and randomly flag the next drive
# resetting it at the beginning of the loop fixed the every other drive problem
# also had a problem trying to pull the serial after the USB had already been removed
# moved the serial check earlier so the program saves it while the drive still exists and can print it later
# had to add a delay after detecting the drive because Windows can show the drive
# before everything on it is actually ready
# reading the auth file only tells me the file exists so i still needed to recreate
# the expected value using the actual drive serial
# now it pulls the serial runs it through the same encoding used by the setup helper and compares that against the file
# if the file is missing or the encoded values do not match then the drive gets flagged
# if the values match then the drive passes and the count of accepted drives goes up
# once a USB passes the accepted drive count goes up and the native list updates
# on the next loop so it stops checking that approved USB
# also needed the native list to update when the number of normal drives changes
# so removing approved drives does not break the count
# unknown drives still trigger the warning and the program waits until they are removed
# it counts how long the drive stays connected and saves the
# serial before removal so there is still something useful to report afterward
# changed the giant blank except into one that prints the actual error
# because silently eating every error made debugging miserable
# current version can tell the difference between a missing auth file a wrong auth file and a correctly registered USB
# im happy with where the logic is sitting now because the full basic authentication loop actually works
