# USB Defender - End User Setup

USB Defender monitors newly connected USB storage devices and checks whether they have been registered with your organization.

Once setup is complete, USB Defender should start automatically when you sign into Windows and run in the background.

---

# 1. Keep the USB Defender Folder Together

Do not move, rename, or delete individual files inside the `USB_Defender` folder unless instructed by your administrator or developer.

The provided folder contains the files required for USB Defender to identify your organization and authenticate registered USB devices.

Extract the provided ZIP file before running the program.

Example:

```text
Downloads
└── USB_Defender
    ├── USB_Auth_Background.py
    ├── Org_ID.txt
    └── other provided files
```

---

# 2. Install Python

USB Defender requires Python 3.

Download and install Python from:

```text
https://www.python.org/downloads/
```

During installation, make sure:

```text
Add Python to PATH
```

is selected.

After installation, open Command Prompt and verify Python is available:

```text
py --version
```

You should receive a Python version number.

---

# 3. Install the Required Python Package

Open Command Prompt and copy and paste:

```text
py -m pip install pywin32
```

Press Enter and allow the installation to finish.

Most of the tools used by USB Defender are already included with Python. `pywin32` provides the Windows-specific functions used to detect and inspect connected drives.

You can verify the installation with:

```text
py -m pip show pywin32
```

---

# 4. Test USB Defender

Open the `USB_Defender` folder.

Run:

```
USB_Auth_Background.py
```

USB Defender should begin monitoring connected drives.

Do not connect an unknown USB during initial setup unless you are testing the warning system.

If USB Defender reports that no Organization ID was found, stop and contact the person who provided the USB Defender package.

Do not create or modify the Organization ID yourself.

---

# 5. Configure USB Defender to Run at Startup

USB Defender should launch automatically whenever you sign into Windows.

Press:

```text
Win + R
```

Enter:

```text
shell:startup
```

and press Enter.

This opens your Windows Startup folder.

Create a shortcut to the USB Defender background program inside this folder.

The shortcut should launch the background script using Python.

A normal shortcut target may look similar to:

```text
"C:\Path\To\Python\python.exe" "C:\Path\To\USB_Defender\USB_Auth_Background.py"
```

If USB Defender should run without opening a Command Prompt window, use `pythonw.exe` instead:

```text
"C:\Path\To\Python\pythonw.exe" "C:\Path\To\USB_Defender\USB_Auth_Background.py"
```

Set the shortcut's **Start in** location to the USB Defender folder.

Example:

```text
C:\Users\YourName\Documents\USB_Defender
```

This is important because USB Defender needs to access the configuration files stored in its folder.

Restart Windows or sign out and back in to test the startup configuration.

---

# 6. Normal USB Behavior

When a registered USB device is connected, USB Defender checks:

```text
USB authentication file
        +
USB drive serial number
        +
Organization ID
        ↓
Authentication comparison
```

If the values match, the USB is accepted.

The approved USB becomes part of the currently trusted drive list and should not repeatedly trigger authentication while it remains connected.

No action should normally be required from the user.

---

# 7. Unknown USB Warning

If USB Defender displays a warning similar to:

```text
WARNING: Unregistered USB Device Detected

This device is not registered with your organization and may present a security risk.

Please remove the device.
```

remove the USB device.

Do not open files from the drive, copy files from it, or reconnect it unless instructed by your administrator.

USB Defender will continue monitoring the drive until it has been removed.

---

# 8. Reporting an Unknown USB

After the USB has been removed, USB Defender may display information similar to:

```text
Device Removed.

Please report the following device information:

Drive: D:\
Serial Number: 1931791469
```

Send both pieces of information to the person responsible for USB Defender.

Use this format:

```text
USB Defender Report

Drive: D:\
Serial Number: 1931791469

The USB device has been removed from the computer.
```

If you know who connected the USB or why it was connected, include that information separately.

Example:

```text
USB Defender Report

Drive: D:\
Serial Number: 1931791469

The USB device has been removed from the computer.

Additional Information:
The drive belongs to John Smith and was connected to transfer project documents.
```

Do not modify the reported serial number.

---

# 9. If a USB You Believe Is Approved Gets Flagged

Remove the USB when instructed.

Send the reported drive information and serial number to the administrator.

Do not attempt to edit:

```text
USB_ID.txt
```

on the USB manually.

The drive may need to be registered again using the organization's USB registration utility.

---

# 10. If USB Defender Stops Working

First confirm that Python is installed:

```text
py --version
```

Then confirm that `pywin32` is installed:

```text
py -m pip show pywin32
```

If necessary, reinstall it with:

```text
py -m pip install --upgrade pywin32
```

Also confirm that the original `USB_Defender` folder and its configuration files have not been moved, renamed, or deleted.

If the problem continues, send the displayed error message to the administrator or developer.

Do not modify the Python files unless you have been instructed to do so.

---

# Important

USB Defender currently identifies registered drives using information stored on the USB combined with information obtained from Windows.

A successful authentication means that the drive matches the registration information expected by this version of USB Defender.

It does not guarantee that every file stored on an approved USB is safe.

Continue following your organization's normal rules for opening files, handling sensitive information, and using removable storage.
