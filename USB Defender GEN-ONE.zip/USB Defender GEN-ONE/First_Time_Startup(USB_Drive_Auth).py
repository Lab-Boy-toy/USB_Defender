
import shutil


UT = input('Developer Setup Utility\nType "Dev" to continue as a developer, or press Enter to exit:\n> ')

if UT.lower() == 'dev':
    print(
        '\nPlease review the README before continuing.\n'
        'This setup utility will configure the Organization ID and prepare the USB_Defender folder for distribution.\n'
    )

    try:
        if len(Org_ID) == 3 and Org_ID.isdigit():
            print(f'Current Organization ID: {Org_ID}')
        else:
            print(f'The current Organization ID ({Org_ID}) is invalid.')
            Org_ID = None

    except NameError:
        Org_ID = None

    if Org_ID == None or not len(Org_ID) == 3 or not Org_ID.isdigit():
        Org_ID = input('Enter a new three-digit Organization ID, example: 123\n> ')

        while not len(Org_ID) == 3 or not Org_ID.isdigit():
            Org_ID = input('Invalid Organization ID. Please enter exactly three numbers.\n> ')

    File = open('Org_ID.txt', 'w')
    File.write(Org_ID)
    File.close()

    shutil.copy("Org_ID.txt", "USB_Defender\\Org_ID.txt")

    print(
        '\nSetup Complete.\n'
        f'Organization ID {Org_ID} has been configured successfully.\n'
        'The USB_Defender end-user folder is now prepared.\n\n'
        'Before distribution, review the User README and make sure the end user understands the required setup instructions.\n'
        'When ready, compress the USB_Defender folder into a ZIP file and send it to the end user.'
    )

else:
    print(
        '\nDeveloper setup was not started.\n'
        'If you received this setup utility unintentionally, no further action is required.'
    )